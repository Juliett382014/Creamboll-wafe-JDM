-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: bwxctne2lo5sgoxq6rb0-mysql.services.clever-cloud.com:3306
-- Generation Time: Nov 15, 2022 at 02:19 PM
-- Server version: 8.0.22-13
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bwxctne2lo5sgoxq6rb0`
--

-- --------------------------------------------------------

--
-- Table structure for table `insumos`
--

CREATE TABLE `insumos` (
  `consecutivo` int NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `descripción` varchar(120) NOT NULL,
  `costo` int NOT NULL,
  `unidad` varchar(15) NOT NULL DEFAULT 'unidad',
  `cantidad` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `insumos`
--

INSERT INTO `insumos` (`consecutivo`, `nombre`, `descripción`, `costo`, `unidad`, `cantidad`) VALUES
(1, 'Helado de frutos rojos cream helado', 'litro', 13000, 'litro', 5),
(2, 'Chantilly', 'en tarro x 250gms', 11500, 'unidad', 1),
(3, 'Oblea', 'paquete x 10 unidades ', 3000, 'unidad ', 1),
(4, 'Salsa de fresa', 'salsa dulce', 2500, 'paquete 250  ', 4),
(5, 'leche condensada', 'lecherita', 4000, 'bolsa 300', 4),
(6, 'Queso costeño', 'queso salado', 10000, 'unidad', 1),
(7, 'cerezas', 'fruta rica', 6000, 'tarro 125  ', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pedidos`
--

CREATE TABLE `pedidos` (
  `cons` int NOT NULL,
  `codigo_producto` int NOT NULL,
  `descripcion` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `valor` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cantidad` int NOT NULL,
  `cliente` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pedidos`
--

INSERT INTO `pedidos` (`cons`, `codigo_producto`, `descripcion`, `valor`, `cantidad`, `cliente`, `total`) VALUES
(1, 4, 'con helado', '7000', 3, 'Mariana Rojas Morales', ''),
(2, 1, 'sin oblea', '4000', 1, 'Mariana Rojas Morales', ''),
(3, 1, 'con helado', '4000', 2, 'Mariana Rojas Morales', '8000'),
(4, 1, 'con helado', '4000', 2, 'Mariana Rojas Morales', '8000'),
(5, 3, 'con salsa, oreo, y salsa', '6000', 2, 'Mariana Rojas Morales', '12000');

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE `productos` (
  `consecutivo` int NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripción` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `valor` int NOT NULL,
  `costo` int NOT NULL,
  `cantidad` int NOT NULL,
  `stop_min` int NOT NULL,
  `stop_max` int NOT NULL,
  `imagen` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`consecutivo`, `nombre`, `descripción`, `valor`, `costo`, `cantidad`, `stop_min`, `stop_max`, `imagen`) VALUES
(1, 'Oblea Sencilla', 'Salsas\r\nChantilly\r\nChispitas\r\nQueso\r\nHelado', 4000, 3000, 40, 20, 60, 'corazoncito.png'),
(3, 'Oblea Me Provoca', 'Salsas\r\nQueso\r\nChantilly\r\nChispitas\r\nGalleta Oreo\r\n\r\nHelado\r\n', 6000, 5000, 20, 9, 10, 'corazoncito.png'),
(4, 'Oblea Frutal', 'Salsas\r\nChantilly\r\nChispitas\r\nFruta\r\nQueso\r\nHelado', 7000, 6000, 12, 8, 4, 'corazoncito.png');

-- --------------------------------------------------------

--
-- Table structure for table `receta`
--

CREATE TABLE `receta` (
  `consecutivo` int NOT NULL,
  `cons_producto` int NOT NULL,
  `cons_insumo` int NOT NULL,
  `unidad` varchar(10) NOT NULL,
  `cantidad` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `receta`
--

INSERT INTO `receta` (`consecutivo`, `cons_producto`, `cons_insumo`, `unidad`, `cantidad`) VALUES
(1, 1, 1, 'gramos', '15'),
(2, 1, 2, 'gramos', '20'),
(3, 1, 3, 'unidad', '2');

-- --------------------------------------------------------

--
-- Table structure for table `tblusuarios`
--

CREATE TABLE `tblusuarios` (
  `consecutivo` int NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `telefono` int NOT NULL,
  `direccion` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `clave` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cedula` int NOT NULL,
  `email` varchar(40) NOT NULL,
  `perfil` char(2) NOT NULL,
  `estado_cuenta` varchar(9) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `tblusuarios`
--

INSERT INTO `tblusuarios` (`consecutivo`, `nombre`, `telefono`, `direccion`, `clave`, `cedula`, `email`, `perfil`, `estado_cuenta`) VALUES
(1, 'Mariana Rojas Morales', 5264852, 'cr90 # 90 -4', 'Mariana', 21819530, 'marianaconpan@gmail.com', '1', 'activa'),
(2, 'Dahiana Vélez Vélez', 5037507, 'cr79c #96-156', 'Lolacalamidades', 1033178511, 'danielperreo@gmail.com', '1', 'activa'),
(4, 'Juliett Paola Gallo Quinchia ', 5295228, 'cr92 #92-2', 'Banano', 1034918424, 'juliettfeliz@gmail.com', '2', 'activa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `insumos`
--
ALTER TABLE `insumos`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`cons`);

--
-- Indexes for table `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `receta`
--
ALTER TABLE `receta`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `tblusuarios`
--
ALTER TABLE `tblusuarios`
  ADD PRIMARY KEY (`consecutivo`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `insumos`
--
ALTER TABLE `insumos`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `cons` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `productos`
--
ALTER TABLE `productos`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `receta`
--
ALTER TABLE `receta`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblusuarios`
--
ALTER TABLE `tblusuarios`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
