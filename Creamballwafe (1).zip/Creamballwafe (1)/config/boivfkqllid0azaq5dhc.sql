-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: boivfkqllid0azaq5dhc-mysql.services.clever-cloud.com:3306
-- Generation Time: Nov 10, 2022 at 05:33 PM
-- Server version: 8.0.22-13
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boivfkqllid0azaq5dhc`
--

-- --------------------------------------------------------

--
-- Table structure for table `insumos`
--

CREATE TABLE `insumos` (
  `consecutivo` int NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `descripción` varchar(120) NOT NULL,
  `costo` int NOT NULL,
  `unidad` varchar(15) NOT NULL DEFAULT 'unidad',
  `cantidad` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `insumos`
--

INSERT INTO `insumos` (`consecutivo`, `nombre`, `descripción`, `costo`, `unidad`, `cantidad`) VALUES
(1, 'Helado de frutos rojos cream helado', 'litro', 13000, 'litro', 5),
(2, 'Chantilly', 'en tarro x 250gms', 11500, 'unidad', 1),
(3, 'Oblea', 'paquete x 10 unidades ', 3000, 'unidad ', 1),
(4, 'Salsa de fresa', 'salsa dulce', 2500, 'paquete 250  ', 4),
(5, 'leche condensada', 'lecherita', 4000, 'bolsa 300', 4),
(6, 'Queso costeño', 'queso salado', 10000, 'unidad', 1),
(7, 'cerezas', 'fruta rica', 6000, 'tarro 125  ', 2);

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE `productos` (
  `consecutivo` int NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripción` varchar(120) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `valor` int NOT NULL,
  `costo` int NOT NULL,
  `cantidad` int NOT NULL,
  `stop_min` int NOT NULL,
  `stop_max` int NOT NULL,
  `imagen` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`consecutivo`, `nombre`, `descripción`, `valor`, `costo`, `cantidad`, `stop_min`, `stop_max`, `imagen`) VALUES
(1, 'Golosa', 'salsas, helado de frutos rojo', 8000, 4000, 40, 20, 60, '');

-- --------------------------------------------------------

--
-- Table structure for table `receta`
--

CREATE TABLE `receta` (
  `consecutivo` int NOT NULL,
  `cons_producto` int NOT NULL,
  `cons_insumo` int NOT NULL,
  `unidad` varchar(10) NOT NULL,
  `cantidad` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `receta`
--

INSERT INTO `receta` (`consecutivo`, `cons_producto`, `cons_insumo`, `unidad`, `cantidad`) VALUES
(1, 1, 1, 'gramos', '15'),
(2, 1, 2, 'gramos', '20'),
(3, 1, 3, 'unidad', '2');

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `consecutivo` int NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `telefono` int NOT NULL,
  `direccion` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `clave` varchar(60) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cedula` int NOT NULL,
  `email` varchar(40) NOT NULL,
  `perfil` char(2) NOT NULL,
  `estado_cuenta` varchar(9) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`consecutivo`, `nombre`, `telefono`, `direccion`, `clave`, `cedula`, `email`, `perfil`, `estado_cuenta`) VALUES
(1, 'Mariana Rojas Morales', 5264852, 'cr90 # 90 -4', 'Mariana', 21819530, 'marianaconpan@gmail.com', '1', 'activa'),
(2, 'Dahiana Vélez Vélez', 5037507, 'cr79c #96-156', 'Lolacalamidades', 1033178511, 'danielperreo@gmail.com', '1', 'activa'),
(4, 'Juliett Paola Gallo Quinchia ', 5295228, 'cr92 #92-2', 'Banano', 1034918424, 'juliett:D@gmail.com', '2', 'activa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `insumos`
--
ALTER TABLE `insumos`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `receta`
--
ALTER TABLE `receta`
  ADD PRIMARY KEY (`consecutivo`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`consecutivo`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `insumos`
--
ALTER TABLE `insumos`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `productos`
--
ALTER TABLE `productos`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `receta`
--
ALTER TABLE `receta`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `consecutivo` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
