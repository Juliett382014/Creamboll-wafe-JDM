<?
$host="";
$user="";
$pwd="";
$db="";
$puerto="";
$con = mysqli_connect($host, $user, $pwd, $db) or
die("Problemas con la conexión");
?>