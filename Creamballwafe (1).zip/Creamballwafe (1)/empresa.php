<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<?include 'presentacion.php'?>
  
<?include 'menu.php'; ?>
 
<div class="container" style="margin-top:30px">

  <div class="row">
   
    <div class="col-sm-4">

      <font color="black" face="Lucida Bright">
      <h2>Empresa: Creamball Wafe<br><img src="img/sallallin2.png" width="300" height="250"</h2></font>
    
     
      
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <font color="black" face="Lucida Bright">
      <h2>Nuestra empresa</h2>
      </font>
      
      <div class="fakeimg"></div>
      <br>
      <h5></h5>
      <div class="fakeimg"></div>
      <p>Nuestra empresa es un proyecto de grado 11°, que esta orientada a toda clase de público, para satisfacer su degustación, el disfrute y su comodidad con los servicios que presta nuestra empresa. Su estructura esta basada en una oblea con helado,frutas y chantilly, y ya su respctivo queso y salsas, con una variedad de dulces, esto con el fin de que prueben una oblea diferente y no la tradicional de siempre.</p>
    </div>
  </div>
</div>
   <br>
  <br>
<center>
<marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
Creamball Wafe, te dará sensaciones con sabor y colores
</font>
</marquee>
</center>

</body>
</html>