<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<?include 'presentacion.php'?>
  
<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <font color="black" face="Lucida Bright">
      <h3>Nuestros Estudios</h3>
      </font>
      <hr class="d-sm-none">
      <img src="img/puesto.jpg" width="300" height="350" /> <br>
    </div>
   
    <div class="col-sm-8">
      <font color="black" face="Lucida Bright">
      <h3 align="center">Nuestros Estudios de Mercado.</h3>
      </font>
     <div class="fakeimg"></div>
      <p align="justify">Aun no se venden, ni tenemos obleas, parcialmente con lo que contamos de la empresa, es el estudio de la competencia que hay en el mercado y como poder atraer al público para generar mayores ingresos y que el proyecto sea rentable de acuerdo a las expectativas que tenemos acerca de este.
<br><br>
        Nuestra competencia son los demás locales de obleas que se están enfocando en mejorar la producción y reutilizar la idea tradicional de la oblea con estandaras mucho más elevados y hacerla innovadora.

        <br><br>
         Nuestra competencia son los demás locales de obleas que se están enfocando en mejorar la producción y reutilizar la idea tradicional de la oblea con estandaras mucho más elevados y hacerla innovadora.

       <br><br>
        Nuestra empresa esta ubicada en la comuna 7, (Robledo Aures/medellín) en la institución educativa fe y alegría aures con Carrera 95 # 89-73.
      </p>

      
    </div>
  </div>
</div>
  <br>
  <br>
<center>
<marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
Creamball Wafe, te dará sensaciones con sabor y colores
</font>
</marquee>
</center>

</body>
</html>