<?
include 'config/conexion.php';
//include 'head.php';
$cantidad=0;
 if (isset($_POST['producto'])){
$producto=$_POST['producto'];
$cantidad=$_POST['cantidad'];
$descripcion=$_POST['descripción'];
$usuario=$_POST['usuario'];
$valor=0.0;
$total=0.0;
$sql="SELECT consecutivo, nombre, descripción, valor
from productos  where consecutivo= '$producto'";
$reg =mysqli_query($con,$sql)
or die("Problemas en la conexión");
while($r=mysqli_fetch_array($reg)){
  $valor=$r['valor'];
  $nombre=$r['nombre'];
  
}//fin mientras
   $total=$cantidad*$valor;
$sqlins="INSERT INTO pedidos(cantidad, cliente, codigo_producto, descripcion, valor, total)values('$cantidad','$usuario','$producto',
'$descripcion','$valor','$total')";
$consulta=mysqli_query($con,$sqlins)or die("Error ".$sqlins);


mysqli_close($con);
 
 }
?>
  <META HTTP-EQUIV="REFRESH" CONTENT="1;URL=https://creamballwafe.creamballwafe.repl.co/"> </head>