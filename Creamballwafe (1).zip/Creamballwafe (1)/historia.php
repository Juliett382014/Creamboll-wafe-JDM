<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<?include 'presentacion.php'?>
  
<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <font color="black" face="Lucida Bright">
      <h3>Historia de: Creamball Wafe</h3>
      </font>
      <hr class="d-sm-none">
      <img src="img/sallallin2.png" width="360" height="270" /> <br>
    </div>
   
    <div class="col-sm-8">
      <font color="black" face="Lucida Bright">
      <h3 align="center">Nuestra historia</h3>
      </font>
     <div class="fakeimg"></div>
      <p align="justify">La historia de la empresa comienza en el año 2021, cuando nos encontrabamos juntas tres compañeras en un mismo grado, Marisa Sosa, Mariana Rojas y Dahiana Vélez; teniamos que desarrollar un emprendiento que fuera diferente e innovador, nuestras ideas eran diferentes pero siempre todas fueron por una misma línea que era la comida, hasta que decidimos unir las tres ideas, y entonces fue ahí donde la encontramos, Creamball Wafe, una empresa de obleas con helado que permitiera a las personas combinar las cosas que más les gusta y tenerlas en un solo producto.</p>
<br>
      <font color="black" face="Lucida Bright">
      <h3 align="center">Misión</h3>
      </font>
      <div class="fakeimg"></div>
<p align="justify">Nuestra misión es crear una microempresa de obleas con helado, chantilly, diferentes salsas (arequipe, lecherita, mora, fresa, chicle, etc) y productos (frutas, galletas, chispitas, golochips, etc). Queremos generar un producto novedoso, delicioso y de buena calidad, atractivo para las personas, que con tan solo su imagen los invite a probar y experimentar. Queremos hacer lo mejor para nuestros clientes de forma que cualquier consejo contribuira en la busqueda de la continua excelencia, para así crear un ambiente agradable para brindarles una sonrisa con el simple hecho de comer algo dulce.</p>
      <br>

       <font color="black" face="Lucida Bright">  
      <h3 align="center">Visión</h3>
       </font>
      <div class="fakeimg"></div>
        <p align="justify">Nuestra visión es convertir la microempresa en la mejor vendedora de obleas de calidad, aceptar con total responsabilidad y empeño el proposito de esta microempresa para brindar los mejores productos y servicios a nuesrtos clientes, innovando permanentemente el producto en los procesos de desarrollo y consolidarla como una empresa en crecimiento para que los clientes puedan llegar a tener una sensación agradable y desgustante en su paladar y que día a día puedan disfrutar de nuestro excelente servicio.</p>
      <br>

       <font color="black" face="Lucida Bright">
      <h3 align="center">Filosofía</h3>
       </font>
      <div class="fakeimg"></div>
         <p align="justify">Nuestra filosofía es actuar siempre de manera honesta, responsable y correcta, sin dañar lo moral y lo ético; tomando de cada cliente lo más especial y esencial. Trabajando duro, creyendo en los ideales de cada una de nosotras, teniendo mucha perseverancia y la concentración debida.</p>
      
    </div>
  </div>
</div>
  <br>
  <br>
<center>
<marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
Creamball Wafe, te dará sensaciones con sabor y colores
</font>
</marquee>
</center>

</body>
</html>