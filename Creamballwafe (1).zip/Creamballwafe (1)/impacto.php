<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<?include 'presentacion.php'?>
  
<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Impacto de: Creamball Wafe</h2>
       <img src="img/sallallin2.png" width="320" height="250" /> <br>
     
      
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>Nuestro Impacto</h2>
      <div class="fakeimg"></div>
      <br>
      <h5>¿Qué huella queremos dejar en las personas?</h5>
      <div class="fakeimg"></div>
      <p>Con este emprendimiento queremos dejar en nuestros clientes una huella, no solo de un producto que les guste sino también de un sentimiento donde se sientan comodos y satisfechos con el producto y el espacio que se les brinda.</p>
    </div>
  </div>
</div>
    <br>
  <br>
<center>
<marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
Creamball Wafe, te dará sensaciones con sabor y colores
</font>
</marquee>
</center>

</body>