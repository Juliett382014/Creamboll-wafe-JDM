<?
//session_start();
$usuario=$_REQUEST['usuario'];
$clave=$_REQUEST['clave'];
 $clave_crypt="";
if(isset($usuario)&& isset($clave) ){
  include 'config/conexion.php';
 // $salt=substr($usuario, 0,2);
// $clave_crypt=crypt($clave,$salt);
  $sql="SELECT nombre, clave, perfil
FROM tblusuarios WHERE email='$usuario' AND clave='$clave'";
  $consulta=mysqli_query($con,$sql);
  $nfilas=mysqli_num_rows($consulta);
  while($reg=mysqli_fetch_array($consulta)){
       $_SESSION["usuario_valido"]=$reg['nombre'];
       $nombre=$reg['nombre'];
       $_SESSION["perfil"]=$reg['perfil'];
  }//fin mientras
  mysqli_close($con);
  if($nfilas>0){
    $usuario_valido=$nombre;
    $_SESSION['usuario_valido']=$usuario_valido;
}//fin si
}//fin si hay usuario y clave
?>
<!DOCTYPE html>
<html lang="en">
<?include 'head.php' ?>
<body>
<?// include presentacion.php ?>
<?include 'publicidad.php'?>
 
<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2><b>CREAMBALL WAFE</b>
      <br>Bienvenidos <?
      
        echo $_SESSION['usuario_valido'];

        ?>
      </h2> 
      <h6>"Te dará sensaciones con sabor y colores."</h6>
   <div class=""></div>
    <h6>Somos una empresa colombiana dedicada a las obleas</h6>
      <img src="img/deliciosas.jpg" width="150" height="150" />
        <br><br>
      </ul>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
<!-- <h2>Oblea con chispitas</h2> -->
<!-- <img src="img/chispitass.jpg" width="150" height="150" /> -->
      <div class="fakeimg">.</div>
      <p></p>
      <br>
      <div class="fakeimg">.</div>
      <p></p>
    </div>
  </div>
</div>

<div class="jumbotron text-center" style="margin-bottom:0">

 <? 
    if (isset($_SESSION["usuario_valido"])){
      if($_SESSION['perfil']==1){
          include 'lista_productos.php';
          include 'pedidos.php';
        }

      if($_SESSION['perfil']==2){
          include 'lista_productos.php';
          include 'pedidos.php';
        
        }
         
     
         }else{
       include 'usuarios.php';
         }
     ?>
</div>

</body>
</html>