<? 
include 'config/conexion.php';
include 'head.php';
?>
<section class="page-section" id="usuarios">

            <div class="container px-4 px-lg-5 h-100">
               
                    <div class="col-lg-8 align-self-end">
<h1 class="text-white font-weight-bold"> </h1>
                      <h1>Listado de usuarios</h1>
<table>

  <tr><th>Nombre</th><th>Perfil</th><th>Correo</th><th>Clave</th></tr>
<?
$sql="SELECT nombre, perfil, email, clave from tblusuarios";
$reg =mysqli_query($con,$sql)
or die("Problemas en la conexión");
while($r=mysqli_fetch_array($reg)){
  echo '<tr><td>'.$r['nombre'].'</td>';
  echo '<td>'.$r['descripción'].'</td>';
  echo '<td>'.$r['valor'].'</td>';
   echo '<td><img src="img/'.$r['imagen'].'"></td>';
  echo '</tr>';
}//fin mientras
mysqli_close($con);
?>
</table>
                    </div>
            </div>
            </section> 