<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="index.php">Inicio</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="justificacion.php">Justificación</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="productos.php">Productos</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="estudio.php">Estudio de Mercado</a>
         <li class="nav-item">
        <a class="nav-link" href="empresa.php">Empresa</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="historia.php">Historia</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="objetivos.php">Objetivos</a>
      </li>
      
  <li class="nav-item">
        <a class="nav-link" href="impacto.php">Impacto</a>
      </li>   

       <li class="nav-item">
        <a class="nav-link" href="#login">Ingreso</a>
      </li> 
      
      <li class="nav-item">
        <a class="nav-link" href="#pedidos">Pedidos</a>
      </li> 
      </li> 
    </ul>
  </div>  
</nav>