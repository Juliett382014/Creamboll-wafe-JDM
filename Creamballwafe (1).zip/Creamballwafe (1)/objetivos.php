
<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<?include 'presentacion.php'?>
  
<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <font color="black" face="Lucida Bright">
      <h3>Objetivos de: Creamball Wafe</h3></font>
      <hr class="d-sm-none">
      <img src="img/sallallin2.png" width="320" height="252" /> <br>
    </div>
    <div class="col-sm-8">
      <font color="black" face="Lucida Bright">
      <h3>Nuestros objetivos.</h3></font>
      <div class="fakeimg"></div>
      <br>
      <font color="black" face="Lucida Bright">
      <h5>Objetivos de Creamball Wafe</h5></font>
      <div class="fakeimg"></div>
      <p>
        Nuestros objetivos son que los estudiantes de la institución puedan tener una mayor degustación en las horas de clase y descansos.<br>
     <ul><li> Recaudar fondos suficientes para la institución.</li>

 <li>Procurar que la comunidad pueda sentir una buena degustación sobre nuestro proyecto</li>

<li> Facilitar por el medio virtual la entrega del producto.</li>

<li>Concretar muchas ventas.</li> 

<li>Controlar óptimamente los gastos, para poder ahorrar.</li>

 <li>Expandir nuestro emprendimiento.</li>

 <li>Utilizar y perfeccionar los sistemas de entrega y de pago.</li>

 <li>Disfrutar de un espacio armonioso y agradable.</li>
        
<li> Contribuir a una restricción solo para los estudiantes de la institución, no será para entornos ajenos a la institución mientras se logre agrandar mas el negocio. </li>
     </ul> </p>
    </div>
  </div>
</div>
   <br>
  <br>
<center>
<marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
Creamball Wafe, te dará sensaciones con sabor y colores
</font>
</marquee>
</center>

</body>
</html>