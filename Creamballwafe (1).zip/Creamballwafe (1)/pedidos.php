<? 
include 'config/conexion.php';
include 'head.php';

?>
<section class="page-section" id="pedidos">

            <div class="container px-4 px-lg-5 h-100">
               
                    <div class="col-lg-8 align-self-end">
<h1 class="text-white font-weight-bold"> </h1>
                      <h1>Haga su pedidos</h1>
<form action="guardar_pedido.php" method="post" class="form-group">
 <div><select name="producto">
<option value="">Seleccione</option>
<?
$sql="SELECT consecutivo, nombre, descripción, valor, imagen from productos";
$reg =mysqli_query($con,$sql)
or die("Problemas en la conexión");
while($r=mysqli_fetch_array($reg)){
  echo '<option value="'.$r['consecutivo'].'">'.$r['nombre'].'</option>';
   
}//fin mientras
echo'</select></div>';
mysqli_close($con);
?>
<div><input type="number" 
        name="cantidad" 
          placeholder="cantidad" 
             ></div>
   <div><input type="text" 
        name="descripción" 
          placeholder="descripcion">

     <div><input type="text" 
           name="usuario" 
            value="<?echo$_SESSION['usuario_valido']?>"
            placeholder="usuario"readonly >
     
   </div>
   </div>
   <div>
    <button class="btn btn-warning">Enviar</button> 
   </div>
</form>
                      
                    </div>
            </div>
            </section> 