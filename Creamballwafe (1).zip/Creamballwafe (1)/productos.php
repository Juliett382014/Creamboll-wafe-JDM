<!DOCTYPE html>
<html lang="en">
<?include 'head.php'?>
<body>

<?include 'presentacion.php'?>
  
<?include 'menu.php'; ?>

<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
    <div text-align="center">
       <font color="black" face="Lucida Bright">
      <h3>¡Prueba Nuestros productos!</h3>
       </font>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
       <font color="black" face="Lucida Bright">
      <h3>Productos Creamball Wafe </h3>
       </font>
      <div class="fakeimg">
        <img src="img/obleas.jpg" width="300" height="200" />
      </div>
      <br><br>
      <div class="fakeimg"></div>
       <font color="black" face="Lucida Bright">
      <h3>Oblea me provoca.</h3>
       </font>
      <img src="img/ricorico.jpg" width="300" height="200"
       />
      <p> <b>Ingredientes:</b> <br>
         <b>-</b>Salsas <br>
         <b>-</b>Chantilly  <br>
         <b>-</b>Queso  <br>
         <b>-</b>Chispitas <br>
         <b>-</b>Galletas oreo o chocolatina <br>
         <b>-</b>Helado<br>
            <marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
$6.000
</font>
   </marquee </p>
       <font color="black" face="Lucida Bright">
       <h3>Oblea sencilla.</h3>
       </font>
      <img src="img/obleasmaridahi.jpg" width="300" height="200" />
      <p><b>Ingredientes:</b><br>
         <b>-</b>Salsas  <br>
         <b>-</b>Chantilly  <br>
         <b>-</b>Queso  <br>
         <b>-</b>Chispitas <br>
         <b>-</b>Helado  <br>
              <marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
$4.000
</font>
   </marquee></p>

          <font color="black" face="Lucida Bright">
      <h3>Oblea frutal.</h3>
          </font>
      <img src="img/carambola.jpg" width="300" height="200" />
      <p><b>Ingredientes:</b> <br>
         <b>-</b>Salsas  <br>
         <b>-</b>Chantilly  <br>
         <b>-</b>Chispitas  <br>
         <b>-</b>Queso  <br>
         <b>-</b>Frutas como: (fresa, banano, kiwi, uvas, piña, mango, peras y manzanas) <br>
 <b>-</b>Helado  <br> 
            <marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
$7.000
</font>
</marquee>  </p>
    </div>
  </div>
</div>
    <br>
  <br>
<center>
<marquee width=70% bgcolor=#7fc9d7>
<font face=optima  color=black size=5>
Creamball Wafe, te dará sensaciones con sabor y colores
</font>
</marquee>
</center>
</body>
</html>
