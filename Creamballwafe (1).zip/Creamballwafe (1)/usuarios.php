<section id="login">

<div class="container">
<div class="card usuario">
<div class="card-header">
<div class="card-body">
<form name ="flogin"  action = "index.php" method="post">
<div class = "form-group row">
<label class ="col-md-4 col-form-label text-md-right"> Usuario: </label>
<div class='col-md-4'>
<input type='email'
class='form-control'
name='usuario'
maxlength='40' 
size='20'>
</div></div>
  <div class ='form-group row'>
    <label for ='password' class='col-md-4 col-form-label
      text-md-right'> Clave: </label>
    <div class='col-md-4'>
      <input type='password'
        id='password'
        class='form-control'
        name='clave' maxlength='8' size='10'
        <div></div>
      <div class='col-md-4 offset-md-4'><br>
        <button type='submit' value='entrar' class='btn btn-light'>
          Ingresar
        </button>
      </div>
</form>
     
</div></div></div> </div>
</section>